/*
 * main.c
 *
 *  Created on: 20.03.2009
 *      Author: user01
 */
#include <io.h>
#include <signal.h>
#include <stdlib.h>
#include <stdint.h>
#include "glcd.h"
#include "graphics.h"
#include "fft.h"

#define   Num_of_Results   256

char GRam[1024];        						// Bildspeicher
int16_t real[2][256];							// Speicher f�r Signal
int16_t imag[256];
uint16_t adc_buff=0, fft_buff=1;				// jeweils aktuellen Puffer merken

volatile unsigned int flag=0;					// Flag -> Puffer vollgeschrieben
volatile unsigned int busy=0;

void clock_init();
void adc12_init();

int main()
{
	int16_t x;									// Z�hlvariable
	uint16_t spektrum;							// Speicher f�r Spektrum


	clock_init();								// Clock initialisieren
	adc12_init();								// AD-Wandler initialisieren
	SPI_A1_init();           					// Schnittstelle initialisieren
	GLCD_INIT();             					// Grafik - LCD initialisieren
	GLCD_HBEL(on);								// Hintergrundbeleuchtung an

	ADC12CTL0 |= ENC;                         	// Start conversion


	P1DIR|=(1<<0);								// Ausgang f�r "Debugausgaben"

	_BIS_SR(GIE);                 			  	// Enable interrupts

	while(1)									// Endlosschleife
	{
		if(flag)								// Einmal Puffer vollgeschrieben?
		{
			flag=0;								// Timing wird �ber busy realisiert
			busy=1;								// ich hab zu tun!
			// P1OUT |= (1<<0);
			fft_buff=1-adc_buff;				// den Puffer w�hlen der gerade
												// nicht! beschrieben wird

			//P1OUT |= (1<<0);
			fft(&real[fft_buff][0],imag,1);		// FFT
			//P1OUT &= ~(1<<0);

			for (x=0;x<128;x++)					// Betrag berechnen (untere 128)
			{
				MPYS=real[fft_buff][x];			// (Re{x}
				OP2=real[fft_buff][x];			// * Re{x})
				MACS=imag[x];					// + (Im{x}
				OP2=imag[x];					// * Im{x})

				if(RESHI)						// falls n�tig
				{
					spektrum=_sqrt(RESHI);		// Wurzel ziehen
					line(x,64,x,64-spektrum,1); // Linie Zeichnen
				}

				real[fft_buff][x]=0;			// Puffer wieder l�schen
				real[fft_buff][x+128]=0;
				imag[x]=0;
				imag[x+128]=0;
			}

			Send_Bild((char*)GRam);				// Anzeige aktualisieren

			for(x=0;x<1024;x++) GRam[x]=0;		// Grafikram leeren
												// Damit leer f�r n�chstes Bild

			busy=0;								// Busy-Flag l�schen -> FERTIG
			ADC12IE = (1<<0);					// Interrupt wieder aktivieren
												// -> Falls schnell genug keine �nderung,
												// sonst reaktiviert
			// P1OUT &= ~(1<<0);
		}
	}

	return 0;
}

/**************** Initialisierung der MCU - Taktquellen ***********************/
void clock_init() 								// Funktion Taktinitialisierung
{
  volatile unsigned int i;  					// Zaehlvariable
  WDTCTL = WDTPW + WDTHOLD; 					// stoppt den WDT
  BCSCTL1 |= XTS;           					// ACLK=LFXT1=HF Quarz (16Mhz)
  BCSCTL3 |= LFXT1S_2;       					//Bereich in dem der Quarz liegt
  BCSCTL1 |= DIVA_0;							// Vorteiler = 1
  do
  {
    IFG1 &= ~OFIFG;       	 					// l�scht das OSC-FehlerFlag
    for (i = 0xFF; i > 0; i--);  				// Einschwingzeit
  }
  while (IFG1 & OFIFG);							// OSC Fehlerflag wieder gesetzt?
  BCSCTL2 |= SELM_3;     						// MCLK=LFXT1 (Schwingquarz an XT1)
  BCSCTL2 |= DIVM_0;	 						// Vorteiler = 1
  return;
}

void adc12_init()
{
	// ADC initialisieren
	P6SEL |= (3<<0);                            			// Enable A/D channel A

	P2SEL |= BIT3;                            			// Set for Timer A1
	P2DIR |= 0x08;

	ADC12CTL0  = ADC12ON;								// AD_wandler an
	ADC12CTL1  = CONSEQ_2+ADC12SSEL_1+ADC12DIV_3+SHS_1+ISSH; // repeated single channel, timerA1, ACLK/4, fallende Flanke
	ADC12MCTL0 = INCH_1 + SREF_0;						// Kanal 0, VCC Referenz
	ADC12IE = (1<<0);                         			// Enable ADC12IFG.0

	// TimerA initialisieren
	TACCR0 = 1249;										// Compareregister 1250-1 -> resultierend 12,8KHz
	TACCR1 = 625;										// 650 Takte High -> Flankengesteuert, jeder andere Wert w�rde auch gehen

	TACCTL1 = OUTMOD_7;                       			// Set/reset
	TACTL = TACLR | MC_1 | TASSEL_1;          			// ACLK, clear TAR, up mode

	return;
}

interrupt (ADC12_VECTOR) ADC12ISR ()
{
  static unsigned int index = 0;

  real[adc_buff][index++] = (ADC12MEM0-2048);			// Offsetkorrektur

  if(index==Num_of_Results)
  {
	  adc_buff=1-adc_buff;								// Puffer wechseln
	  index=0;											// Von vorn anfangen
	  if(busy) ADC12IE = 0x0000;						// noch nicht fertig? -> Interrupt abschalten
	  flag=1;											// Fertig an Main-Loop melden
  }
}
