/*******************************************************************************

Headerdatei f�r die Ansteuerung des DOGM128 Display von Electronic Assembly

Autor:          Michael Petzold
Datum:          10.03.2009
Lizenz:         Creative Commons Attribution-ShareAlike 3.0 Unported
                http://creativecommons.org/licenses/by-sa/3.0/legalcode

Prozessor:      MSP430F2618

*******************************************************************************/
#ifndef GLCD_h
#define GLCD_h

/**************** Defines *****************************************************/
#define on 1
#define off 0
//Steuerleitungen
#define GLCD_CS 1
#define GLCD_A0 0
//Leitungen f�r die Hintergrundbeleuchtung
#define GLCD_H1 2
//Port 5 f�r die Steuerleitungen des GLCD
#define GLCD_P P7OUT
#define GLCD_D P7DIR
#define GLCD_S P7SEL

/**************** Funktionsprototypen *****************************************/
void SPI_A1_init(void);           //Schnittstelle initialisieren
void GLCD_INIT(void);             //Grafik - LCD initialisieren
void Send_Bild(char* data);       //Sendet den Bildspeicher an das Display
void goto_xy(char x, char y);     //Stellt die XY - Position ein
void GLCD_HBEL(char);             //Hintergrundlicht einschalten
void Set_Con(char i);             //Kontrast einstellen

#endif
