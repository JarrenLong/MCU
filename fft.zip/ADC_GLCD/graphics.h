/*******************************************************************************

Headerdatei f�r die Grafikroutinen

Autor:          Andreas Wenzel
Datum:          07.03.2009
Lizenz:         Creative Commons Attribution-ShareAlike 3.0 Unported
                http://creativecommons.org/licenses/by-sa/3.0/legalcode


*******************************************************************************/
#ifndef GRAFICS_H_
#define GRAFICS_H_

// Funktionsprototypen
void Set_Pixel(int, int, char);             //Pixel setzen
void Set_Byte(char, int, char, char);       //Byte setzen
void line(int, int, int, int, char);        //Linie zeichnen
void circle(int, int, int, char, char);           //Kreis zeichnen
void rect(int, int, int, int, char, char);  //Rechteck zeichnen
void lcd_print(unsigned char*, int, int, char);	    //Text ausgeben
char sgn(int);                         //Vorzeichen bestimmen (f�r Bresenham)

// Externe Variable Grafikram
extern char GRam[];

#endif /* GRAFICS_H_ */
