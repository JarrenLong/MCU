/*******************************************************************************

Routinen zum Zeichnen von:
         - eines einzelnen Punktes an den Koordinaten x, y
         - eines Bytes an den Koordinaten x, y
         - einer Linie von den Koordinaten x1, y1 nach x2, y2
         - eines Rechteckes an den Koordinaten x, y
         - eines Kreises an den Koordinaten x, y
         - einer Textzeile an den Koordinaten x, y

Autor:          Andreas Wenzel, Michael Petzold
Datum:          10.03.2009, 12.03.2009
Lizenz:         Creative Commons Attribution-ShareAlike 3.0 Unported
                http://creativecommons.org/licenses/by-sa/3.0/legalcode

*******************************************************************************/

/**************** Includes ****************************************************/
#include "graphics.h"
#include "font_8x6.h"


/**************** setzt ein einzelnes Pixel an x, y ***************************/
//Parameter:
//  x,y: Koordinaten (0..127,0..63)
//  col: Farbe (1->Schwarz, 0->Weiss)
void Set_Pixel(int x, int y, char col)
{
  //Pr�fen ob Pixel im Zeichnungsbereich, Falls ausserhalb Abbruch
  if((x<0)||(x>127)||(y<0)||(y>63)) return;
  int addr=x+(128*(y>>3));	// Adresse des Pixels berechnen
  switch(col)
  {
    case 0: GRam[addr] &= (char)~(1<<(y&(0x07))); break;// Bit l�schen
    case 1: GRam[addr] |= (char) (1<<(y&(0x07))); break;// Bit setzen
    case 2: GRam[addr] ^= (char) (1<<(y&(0x07))); break;// Bit setzen
  }
  return;
}

/**************** Zeichnet ein Byte an die Stelle x, y ************************/
//Parameter:
//  x,y: Koordinaten (0..127,0..7)
//  col: Farbe (1->Schwarz, 0->Weiss)
void Set_Byte(char byte,int x, char y, char col)
{
  //Pr�fen ob Pixel im Zeichnungsbereich, Falls ausserhalb Abbruch
  if((x<0)||(x>127)||(y<0)||(y>63)) return;
  int addr=x+(128*y);  // Adresse des Pixels berechnen
  switch(col)
  {
    case 0: GRam[addr] &= (char)~byte; break;// Bit l�schen
    case 1: GRam[addr] |= (char) byte; break;// Bit setzen
    case 2: GRam[addr] ^= (char) byte; break;// Bit setzen
  }
  return;
}

/**************** Zeichnet eine Linie von x1, y1 nach x2, y2 ******************/
//Funktion zum Linie Zeichnen (nach Bresenham Algorithmus)
//Direkt von Wikipedia �bernommen
//Parameter:
//  xStart,yStart: Start-Koordinaten (0..127,0..63)
//  xEnd  ,yEnd  : End-Koordinaten (0..127,0..63)
//  col: Farbe (1->Schwarz, 0->Weiss, 2->invertierend)
void line(int xstart, int ystart ,int xend ,int yend ,char col)
{
  int x, y, t, dx, dy, incx, incy, pdx, pdy, ddx, ddy, es, el, err;

  if(ystart==yend)							// Waagerechte Linie
  {
	   if(xstart>xend)						// Reihenfolge anpassen
	   {
		   t=xstart;
		   xstart=xend;
		   xend=t;
	   }

	   for(x=xstart;x<=xend;x++)			// Jeweils ein Pixel setzen
	   {
		   Set_Pixel(x,ystart,col);
	   }
	   return;
  }

  if(xstart==xend)							// Senkrechte Linie
  {
	   if(ystart>yend)						// Reihenfolge anpassen
	   {
		   t=ystart;
		   ystart=yend;
		   yend=t;
	   }

	   int s_page=ystart>>3, e_page=yend>>3;	//Start und Endpage
	   int s_offset=(ystart&(0x07));			//Pixel_offset start
	   int e_offset=1+(yend&(0x07));			//Pixel_offset end

	   char byte=0;								//zu Schreibendes byte

	   if (s_page==e_page)
	   {
			byte=(0xFF<<s_offset) & ~ (0xFF<<e_offset); 						//Bitmuster berechnen
			Set_Byte(byte,xstart,s_page,col);									//und zeichnen
	   }
	   else
	   {
			//1. Startpage zeichnen
			byte=(0xFF<<s_offset);					  		  					//Bitmuster berechnen
			Set_Byte(byte,xstart,s_page,col);									//und zeichnen

			//2. Endpage zeichnen
			byte=0xFF & ~(0xFF<<e_offset);					  					//Bitmuster berechnen
			Set_Byte(byte,xstart,e_page,col);									//und zeichnen

			//3. Zwischenbereich zeichnen
			byte=0xFF;															//Bitmuster berechnen
			for (y=s_page+1;y<e_page;y++)
			{
				Set_Byte(byte,xstart,y,col);									//und zeichnen
			}
	   }

	   return;
  }
  /* Entfernung in beiden Dimensionen berechnen */
  dx = xend - xstart;
  dy = yend - ystart;
  /* Vorzeichen des Inkrements bestimmen */
  incx = sgn(dx);
  incy = sgn(dy);
  if(dx<0) dx = -dx;
  if(dy<0) dy = -dy;
  /* feststellen, welche Entfernung gr��er ist */
  if (dx>dy)
  {
    /* x ist schnelle Richtung */
    pdx=incx; pdy=0;    /* pd. ist Parallelschritt */
    ddx=incx; ddy=incy; /* dd. ist Diagonalschritt */
    es =dy;   el =dx;   /* Fehlerschritte schnell, langsam */
  }
  else
  {
    /* y ist schnelle Richtung */
    pdx=0;    pdy=incy; /* pd. ist Parallelschritt */
    ddx=incx; ddy=incy; /* dd. ist Diagonalschritt */
    es =dx;   el =dy;   /* Fehlerschritte schnell, langsam */
  }
  /* Initialisierungen vor Schleifenbeginn */
  x = xstart;
  y = ystart;
  err = el/2;
  Set_Pixel(x,y,col);
  /* Pixel berechnen */
  for(t=0; t<el; ++t) /* t zaehlt die Pixel, el ist auch Anzahl */
  {
    /* Aktualisierung Fehlerterm */
    err -= es;
    if(err<0)
    {
      /* Fehlerterm wieder positiv (>=0) machen */
      err += el;
      /* Schritt in langsame Richtung, Diagonalschritt */
      x += ddx;
      y += ddy;
    }
    else
    {
      /* Schritt in schnelle Richtung, Parallelschritt */
      x += pdx;
      y += pdy;
    }
    Set_Pixel(x,y,col);
  }
  return;
}

/**************** Zeichnet einen Kreis an der Position x, y *******************/
//Funktion zum Kreis Zeichnen (nach Bresenham Algorithmus)
//Direkt von Wikipedia �bernommen
//Parameter:
//  x0,y0: Mittelpunkt (0..127,0..63)
//  r	 : Radius
//  col  : Farbe (1->Schwarz, 0->Weiss, 2->Invertierend)
void circle(int x0, int y0, int radius, char col, char fill)
{
  int f = 1 - radius;
  int ddF_x = 0;
  int ddF_y = -2 * radius;
  int x = 0;
  int y = radius;
  if(fill)
  {
	  line(x0+radius, y0, x0-radius, y0, col);
	  line(x0, y0+radius, x0, y0-radius, col);
  }
  else
  {
	  Set_Pixel(x0, y0 + radius, col);
	  Set_Pixel(x0, y0 - radius, col);
	  Set_Pixel(x0 + radius, y0, col);
	  Set_Pixel(x0 - radius, y0, col);
  }
  while(x < y)
  {
    if(f >= 0)
    {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x + 1;
    if (fill)
    {
    	line(x0 + x, y0 + y, x0 + x, y0 - y, col);
    	line(x0 + y, y0 + x, x0 + y, y0 - x, col);
    	line(x0 - x, y0 + y, x0 - x, y0 - y, col);
    	line(x0 - y, y0 + x, x0 - y, y0 - x, col);
    }
    else
    {
    	Set_Pixel(x0 + x, y0 + y, col);
    	Set_Pixel(x0 - x, y0 + y, col);
    	Set_Pixel(x0 + x, y0 - y, col);
    	Set_Pixel(x0 - x, y0 - y, col);
    	Set_Pixel(x0 + y, y0 + x, col);
    	Set_Pixel(x0 - y, y0 + x, col);
    	Set_Pixel(x0 + y, y0 - x, col);
    	Set_Pixel(x0 - y, y0 - x, col);
    }
  }
  return;
}

/**************** Zeichnet ein Rechteck an Position x, y **********************/
//Funktion zum Rechtecke Zeichnen
//Parameter:
//  x0, y0: Koordinaten Ecke 1 (0..127,0..63)
//  x1, y1: Koordinate gegn�berliegende Ecke (0..127,0..63)
//  col	  : Farbe   (1->Schwarz, 0->Weiss, 2 Invertierend)
//  fill  : Gef�llt (1->ja, 0->nein)
void rect(int x0, int y0, int x1, int y1, char col, char fill)
{
  if (fill)
  {
    char h=x1;         //Zwischenspeicher und Z�lvariable
    int x_cnt, y_cnt;  //Z�hlvariablen in x und y-Richtung
    char byte=0;
    unsigned char s_page, e_page, s_offset, e_offset;
    if(x1<x0)          //Der Gr��e nach sortieren
    {
      x1=x0; x0=h;     //swap
    }
    if(y1<y0)
    {
      h=y1; y1=y0; y0=h;  //swap
    }
    s_page=(y0>>3);       //Start_page
    e_page=(y1>>3);       //End_Page
    s_offset=(y0&(0x07));  //Pixel_offset start
    e_offset=1+(y1&(0x07));//Pixel_offset end
    if (s_page==e_page)	   //innerhalb einer Page?
    {
      byte=(0xFF<<s_offset) & ~ (0xFF<<e_offset);//Bitmuster berechnen
      for(x_cnt=x0;x_cnt<=x1;x_cnt++)
        Set_Byte(byte,x_cnt,s_page,col);         //und zeichnen
    }
    else                                         //�ber verschiedene Pages
    {
      //1. Startpage zeichnen
      byte=(0xFF<<s_offset);                     //Bitmuster berechnen
      for(x_cnt=x0;x_cnt<=x1;x_cnt++)
        Set_Byte(byte,x_cnt,s_page,col);         //und zeichnen
      //2. Endpage zeichnen
      byte=0xFF & ~(0xFF<<e_offset);             //Bitmuster berechnen
      for(x_cnt=x0;x_cnt<=x1;x_cnt++)
        Set_Byte(byte,x_cnt,e_page,col);         //und zeichnen
      //3. Zwischenbereich zeichnen
      byte=0xFF;                                 //Bitmuster berechnen
      for (y_cnt=s_page+1;y_cnt<e_page;y_cnt++)
      {
        for(x_cnt=x0;x_cnt<=x1;x_cnt++)
          Set_Byte(byte,x_cnt,y_cnt,col);        //und zeichnen
      }
    }
  }
  else
  {
    line(x0,y0,x1,y0,col);
    line(x1,y0,x1,y1,col);
    line(x1,y1,x0,y1,col);
    line(x0,y1,x0,y0,col);
  }
  return;
}

/**************** Gibt einen Text an der Position x, y aus ********************/
//Funktion zur Ausgabe von Text auf dem Display
//Parameter:
//  string  : Zeichenkette
//  x       : Startpunkt x-Richtung (0..127)
//  y       : y-Koordinate  (0..63)
//  c_count : Anzahl der zu schreibenden Zeichen
//  col     : Farbe, 1->Schwarz, 0->Weiss, 2->Aktuellen Hintergrund Invertieren
//					   3->Schwarz mit weissem Hintergrund
//					   4->Weiss mit schwarzem Hintergrund

void lcd_print(unsigned char* string, int x, int y, char col)
{
  char xcnt=0;           //Bytez�hler
  int addr=0;            //Adresse von Zeichen im gespeicherten Font
  char offset=(y&0x07);  //Verschiebung bzgl. kompletter Page
  char page=(y>>3);      //Anfangspage
  char byte;

  char* h_cnt=string;	 //Hilfsvariablen --> zum Zeichen z�hlen
  unsigned char c_cnt=0;

  while(*h_cnt++) c_cnt++;

  if(col==3)			 //Schwarze Schrift, Weisser Hintergrund
  {
	  col=1;			 //Textfarbe neu setzen
	  rect(x,y,x+(6*c_cnt)-1,y+7,0,1); 	//Weisse Box zeichnen
  }

  if(col==4)
  {
	  col=0;			//Weisse Schrift
	  rect(x,y,x+(6*c_cnt)-1,y+7,1,1);	//Schwarze Box
  }



  while(*string)         //Solange Zeichen im String
  {
    addr=6*((*string)-32);    //Adresse des Zeichens im Font berechnen
    for(xcnt=0;xcnt<6;xcnt++) //ein Zeichen Ausgeben
    {
      if(offset)
      {
        Set_Byte((LCD_font[addr+xcnt]<<offset),x,page,col);
        byte=((LCD_font[addr+xcnt])>>(8-offset)) & ~(0xFF<<offset);
        Set_Byte(byte,x,page+1,col);
      }
      else
      {
        Set_Byte((LCD_font[addr+xcnt]),x,page,col);
      }
      x++;
      if (x>=128) break;  //Abbrechen falls darstellbaren Bereich verlassen
    }
    string++;
  }
  return;
}


/**************** Ermittelt das Vorzeichen einer Zahl *************************/
//Signum-Funktion
//Parameter:
//  wert: -128..127
//R�ckgabe:
//  Vorzeichen: -1 oder +1
char sgn(int wert)
{
  if (wert>=0)
    {return 1;}
  else
    {return -1;}
}
