/*
 * fft.h
 *
 *  Created on: 17.03.2009
 *      Author: user01
 */

#ifndef FFT_H_
#define FFT_H_

/******************* Includes *************************************************/
#include <stdint.h>

/******************* Defines **************************************************/
#define LENGTH 	256
#define POWER	8

/******************* Funktionsprototypen **************************************/
inline uint16_t bit_reversal(uint16_t);
void 	sort(int16_t*);
void	fft(int16_t*, int16_t*,uint16_t);

uint16_t _sqrt(uint16_t);
inline int16_t _sin(uint16_t);

/****************** Makros ***************************************************/
#define _cos(x) (_sin((uint8_t)((x)+64)))

#endif /* FFT_H_ */
