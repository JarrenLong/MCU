/*
 * fft.c
 *
 *  Created on: 17.03.2009
 *      Author: user01
 */

#include <io.h>
#include "fft.h"
#include "factors.h"

/******************* Bitumkehr ***********************************************/
inline uint16_t bit_reversal(uint16_t k)
{
    uint16_t i=(k & 0x01), x=7;
    while(k)
    {
    	k>>=1;
		i=(i<<1)+(k & 0x01);
    	x--;
    }
    return i<<x;
}

/******************* Listen sortieren ****************************************/
void sort(int16_t *list)
{
    uint16_t k,i;					//Genutzte Indizes
    int16_t temp;					//Zwischenspeicher

    for (k=1;k<114;k++)
    {
        i=bit_reversal(k);			//Bitfolge umkehren

        if((i>k)&&(i<=(255-k)))		//Falls Daten noch nicht getauscht
        {
            temp=list[i];			//Untere H�lfte Tauschen
            list[i]=list[k];
            list[k]=temp;

			if(i!=255-k)			//Falls oberer Wert nicht Ziel vom unteren
			{
				temp=list[255-i];	//Obere H�lfte auch Tauschen
				list[255-i]=list[255-k];
				list[255-k]=temp;
			}
		}
    }
    return;
}

/******************* schnelles Wurzel ziehen *********************************/
uint16_t _sqrt(uint16_t op)
{
    uint16_t res=0, one=(1<<14);	//Ergebnis "res" und Vergleichswert "one"
    while(one>op) one>>=2;			//Anfang suchen
    do
    {
        if(op>=res+one)
        {
            op-=(res+one);
            res+=(one<<1);
        }
        res>>=1;
        one>>=2;
    }
    while(one);

    return res>>1;
}

/****************** Sinus (�ber Lookup Table) ********************************/
inline int16_t _sin(uint16_t x)
{
	if(x<65) 	return  sine[x];			//1. Quadrant
	if(x<129)	return  sine[128-x];		//2. Quadrant
	if(x<193)	return -sine[x-128];		//3. Quadrant
	return 			   -sine[256-x];		//4. Quadrant
}

/******************* FFT *****************************************************/
void fft(int16_t* real, int16_t* imag, uint16_t window)
{
	uint16_t x, k, i; 		//Verschiedene Z�hlvariablen
	uint16_t a, b;			//Indizes der Knoten f�r eine
							//Verkn�pfung im Butterfly-graph
	uint16_t t=0;			//Index f�r Twiddle-faktoren
	int16_t w_r, w_i;		//Zwischenspeicher f�r Twiddle
							//Faktoren: real und imagin�r


	// Schrittgr��en im Schmetterlingsdiagramm
	uint16_t step_x=2;     	// Gr��e der Wertegruppen
	uint16_t step_t=128;   	// Abstand der Twigglefaktoren
	uint16_t step_k=1;     	// Abstand Dualer Knoten

	// Zwischenspeicher f�r die Berechnung der FFT
	int16_t temp_r, temp_i;	//Realteil, Imagin�rteil

	// Fensterung
	if(window)
	{
		for(x=0;x<128;x++)
		{
			MPYS=w[x];
			OP2=real[x];
			real[x]=(RESHI<<1);
			OP2=real[255-x];
			real[255-x]=(RESHI<<1);
		}
	}

	// Werte umsortieren
	//P1OUT |= (1<<0);
	sort(real);
	//P1OUT &= ~(1<<0);

	// Butterfly
	//P1OUT |= (1<<0);
	while(step_t)							//Stufen des Schmetterlingsgraphen
	{
	    for(k=0; k<LENGTH; k+=step_x)       //Einzelne Bl�cke
		{
	    	t=0;                            //Twiddle_index auf 0
	    	for(i=0; i<step_k; i++)         //Duale Knoten innerhalb der Bl�cke
    	    {
	    		a=k+i;						//Index der Dualen Knoten A
	    		b=a+step_k;					//und B

	    		w_r=_cos(t);				//Twiddlefaktor W bestimmen Real-
	    		w_i=_sin(t);				//und Imagin�rteil

	    		// Komplexe Multiplikation -> Re{Temp}=Re{x}*Re{w}+Im{x}*Im{w}
	    		MPYS=real[b];
	    		OP2=w_r;
	    		MACS=imag[b];
	    		OP2=w_i;
	    		temp_r=(RESHI<<1);

	    		// Im{Temp}=Im{x}*Re{w}-Re{x}*Im{w}
	    		MPYS=imag[b];
	    		OP2=w_r;
	    		MACS=-real[b];
	    		OP2=w_i;
	    		temp_i=(RESHI<<1);

	    		// Verkn�pfen
	    		real[b]=(real[a]-temp_r);
	    		imag[b]=(imag[a]-temp_i);
	    		real[a]+=temp_r;
	    		imag[a]+=temp_i;

	    		// Index des n�chsten Twiddle-Faktors
	    		t+=step_t;
	    	}
	    }
	    step_x<<=1;
	    step_k<<=1;
	    step_t>>=1;
	}
	// Butterflygraph
	//P1OUT &= ~(1<<0);
}
